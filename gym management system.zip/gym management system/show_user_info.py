import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import psycopg2

class ShowUserInfo:
    def __init__(self):
        self.create_main_window()

    def create_main_window(self):
        self.root = tk.Tk()
        self.root.title("SHOW USER INFO")
        self.root.geometry("600x500")
        # Load and display background image for main window
        bg_image = Image.open("logininterface.jpg")
        bg_image = bg_image.resize((1920, 1080))
        self.bg_photo_main = ImageTk.PhotoImage(bg_image)
        bg_label_main = tk.Label(self.root, image=self.bg_photo_main)
        bg_label_main.place(x=0, y=0, relwidth=1, relheight=1)

        self.frame = tk.Frame(bg_label_main, bg="#b3481c", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        # Entry for user input
        self.entry_label = tk.Label(self.frame, text="Enter Gym ID:", width=25, font=("Arial", 14), bg="#f4f4f4", bd=6, relief=tk.RAISED)
        self.entry_label.pack(pady=0)
        self.entry = tk.Entry(self.frame, width=15, font=("Arial", 20))
        self.entry.pack(pady=10)
        self.entry.bind("<Return>", self.search_on_enter)  # Bind <Return> event to search function
        self.search_button = tk.Button(self.frame, text="Search", command=self.search_member,width=25, height=2, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
        self.search_button.pack()

        self.popup_window = None  # Initialize popup window reference

        self.root.mainloop()

    def search_on_enter(self, event):
        self.search_member()

    def search_member(self):
        gym_id = self.entry.get()

        # Fetch data from the database
        try:
            conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost",
                                    port="5432")
            cursor = conn.cursor()
            select_query = f"SELECT * FROM members WHERE gymid='{gym_id}'"
            cursor.execute(select_query)
            data = cursor.fetchone()
            conn.close()

            # Display data in popup window
            if data:
                self.show_popup(data)
            else:
                messagebox.showinfo("Error", "Member not found. Enter a valid Gym ID.")

        except psycopg2.Error as e:
            self.display_error(f"Error fetching member information: {e}")

    def show_popup(self, data):
        if self.popup_window:
            self.popup_window.destroy()  # Destroy previous popup window if exists

        self.popup_window = tk.Toplevel(self.root)
        self.popup_window.title("User Information")
        self.popup_window.geometry("1920x1080")
        # Load and display background image for popup window
        bg_image_popup = Image.open("logininterface.jpg")
        bg_image_popup = bg_image_popup.resize((1920, 1080))
        self.bg_photo_popup = ImageTk.PhotoImage(bg_image_popup)
        bg_label_popup = tk.Label(self.popup_window, image=self.bg_photo_popup)
        bg_label_popup.place(x=0, y=0, relwidth=1, relheight=1)

        # Display user info in popup window
        self.display_member_info(self.popup_window, data)

    def display_member_info(self, window, data):
        # Create and configure labels in the popup window
        labels_info = [
            ("NAME:", data[1]),
            ("HEIGHT:", data[2]),
            ("WEIGHT:", data[3]),
            ("BODY FAT:", data[4]),
            ("MEMBERSHIP TYPE:", data[5]),
            ("CONTACT NUMBER:", data[6]),
            ("DATE OF BIRTH:", data[7]),
            ("OCCUPATION:", data[8]),
            ("EMAIL:", data[9]),
            ("STATUS:", data[10]),
            ("REGISTRATION DATE:", data[11]),
            ("EXPIRY DATE:", data[12])
        ]

        self.frame = tk.Frame(self.popup_window, bg="#b3481c", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        for label_text, value in labels_info:
            label = tk.Label(self.frame, text=label_text + " " + str(value), font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
            label.pack(pady=10)

    def display_error(self, message):
        messagebox.showinfo("Error", message)

if __name__ == "__main__":
    ShowUserInfo()
