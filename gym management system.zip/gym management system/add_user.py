import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from tkcalendar import DateEntry
import datetime
import re  # Import regular expressions for email validation
import psycopg2
from PIL import Image, ImageTk

class AddUser(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ADD USER")
        self.geometry("1929x1080")  # Set window size

        # Load the background image
        bg_image = Image.open("add_interface.jpg")
        bg_image = bg_image.resize((1920, 1080))  # Resize the image to fit the window
        bg_photo = ImageTk.PhotoImage(bg_image)

        # Create a label to hold the background image
        self.bg_label = tk.Label(self, image=bg_photo)
        self.bg_label.image = bg_photo  # Keep a reference to avoid garbage collection
        self.bg_label.pack(fill="both", expand=True)  # Fill the entire window with the image

        # Frame setup
        self.frame = tk.Frame(self.bg_label, bg="#302f2b", bd=10, relief=tk.RAISED, padx=10, pady=10,
                              highlightbackground="#f48d27")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        # Label configurations
        labels = ["NAME", "HEIGHT", "WEIGHT", "BODY FAT", "MEMBERSHIP TYPE", "GYM ID", "CONTACT NUMBER",
                  "DATE OF BIRTH", "OCCUPATION", "EMAIL ID", "ACCOUNT STATUS", "START DATE"]
        for i, label_text in enumerate(labels):
            label = tk.Label(self.frame, text=label_text, font=("Arial", 14), bg="#f4f4f4", bd=6, relief=tk.RAISED,
                             width=20)
            label.grid(row=i, column=0, sticky="w", pady=10, padx=10)

        # Entry fields
        self.tf2 = tk.Entry(self.frame, width=60)
        self.tf2.grid(row=0, column=1, padx=10, pady=10)
        self.tf3 = tk.Entry(self.frame, width=60)
        self.tf3.grid(row=1, column=1, padx=10, pady=10)
        self.tf4 = tk.Entry(self.frame, width=60)
        self.tf4.grid(row=2, column=1, padx=10, pady=10)
        self.tf5 = tk.Entry(self.frame, width=60)
        self.tf5.grid(row=3, column=1, padx=10, pady=10)

        membership_options = ["Monthly", "Yearly", "Half-Yearly", "Quarterly"]
        self.membership_var = tk.StringVar(value="Monthly")  # Default value
        self.tf6 = ttk.Combobox(self.frame, textvariable=self.membership_var, values=membership_options, width=57)
        self.tf6.grid(row=4, column=1, padx=10, pady=10)

        self.tf7 = tk.Entry(self.frame, width=60)
        self.tf7.grid(row=5, column=1, padx=10, pady=10)
        self.tf8 = tk.Entry(self.frame, width=60)
        self.tf8.grid(row=6, column=1, padx=10, pady=10)

        self.cal_dob = DateEntry(self.frame, width=57, background='darkblue', foreground='white', borderwidth=2)
        self.cal_dob.grid(row=7, column=1, padx=10, pady=10)

        self.tf10 = tk.Entry(self.frame, width=60)
        self.tf10.grid(row=8, column=1, padx=10, pady=10)
        self.tf10.insert(tk.END, "N/A")  # Set default value for Occupation

        self.tf11 = tk.Entry(self.frame, width=60)
        self.tf11.grid(row=9, column=1, padx=10, pady=10)

        self.account_status_var = tk.StringVar(value="Active")  # Default value
        self.tf12 = ttk.Combobox(self.frame, textvariable=self.account_status_var, values=["Active", "Inactive"],
                                 width=57)
        self.tf12.grid(row=10, column=1, padx=10, pady=10)

        self.cal_reg_date = DateEntry(self.frame, width=57, background='darkblue', foreground='white', borderwidth=2)
        self.cal_reg_date.grid(row=11, column=1, padx=10, pady=10)

        # Button configuration
        self.bt1 = tk.Button(self.frame, text="ADD INFO", command=self.add_member_info, width=15, height=2,
                             bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
        self.bt1.grid(row=13, column=0, columnspan=2, padx=10, pady=20, sticky="nsew")

    def validate_input(self, input_str, regex_pattern, error_message):
        if not re.match(regex_pattern, input_str):
            messagebox.showwarning("Input Error", error_message)
            return False
        return True

    def add_member_info(self):
        name = self.tf2.get()
        height = self.tf3.get()
        weight = self.tf4.get()
        bodyfat = self.tf5.get()
        membershiptype = self.membership_var.get()
        gymid = self.tf7.get()
        contact_number = self.tf8.get()
        dob = self.cal_dob.get_date().strftime('%Y-%m-%d')  # Get formatted date from DateEntry widget
        occupation = self.tf10.get()
        email = self.tf11.get()
        account_status = self.account_status_var.get()
        reg_date = self.cal_reg_date.get_date().strftime('%Y-%m-%d')  # Get formatted date from DateEntry widget

        # Input validation
        if not all([name, height, weight, bodyfat, gymid, contact_number, dob, occupation, email]):
            messagebox.showwarning("Warning", "Please fill in all required fields.")
            return

        # Input validation for NAME field
        if not re.match(r'^[a-zA-Z\s]+$', name):
            messagebox.showwarning("Warning", "Name should contain alphabets.")
            return

        if not height.isdigit() or not weight.isdigit() or not bodyfat.isdigit() or not contact_number.isdigit():
            messagebox.showwarning("Warning", "Height, Weight, Body Fat, and Contact Number should be integers.")
            return

        if not gymid.isdigit():
            messagebox.showwarning("Warning", "Enter only Number In GYM ID.")
            return

        if not re.match(r'^\d{10}$', contact_number):
            messagebox.showwarning("Warning", "Contact Number should be a 10-digit integer.")
            return

        if not re.match(r'^[a-zA-Z\s+(/)]', occupation):
            messagebox.showwarning("Warning", "Occupation should contain alphabets.")
            return

        if not re.match(r'^[a-zA-Z0-9._%+-]+@(gmail\.com|yahoo\.com)$', email):
            messagebox.showwarning("Warning", "Email should be in the format ex(anish@gmail.com) and end with gmail.com or yahoo.com.")
            return

        # Calculate Expiry Date based on Membership Type and Registration Date
        reg_date_obj = datetime.datetime.strptime(reg_date, '%Y-%m-%d')
        if membershiptype == "Monthly":
            expiry_date = (reg_date_obj + datetime.timedelta(days=30)).strftime('%Y-%m-%d')
        elif membershiptype == "Yearly":
            expiry_date = (reg_date_obj + datetime.timedelta(days=365)).strftime('%Y-%m-%d')
        elif membershiptype == "Half-Yearly":
            expiry_date = (reg_date_obj + datetime.timedelta(days=182)).strftime('%Y-%m-%d')
        elif membershiptype == "Quarterly":
            expiry_date = (reg_date_obj + datetime.timedelta(days=91)).strftime('%Y-%m-%d')
        else:
            expiry_date = ""

        try:
            conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost",
                                    port="5432")
            cursor = conn.cursor()
            insert_query = "INSERT INTO members(name, height, weight, bodyfat, membershiptype, gymid, " \
                           "contact_number, dob, occupation, email, account_status, reg_date, expiry_date) " \
                           "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            cursor.execute(insert_query, (
                name, height, weight, bodyfat, membershiptype, gymid, contact_number, dob, occupation, email,
                account_status, reg_date, expiry_date))
            conn.commit()
            messagebox.showinfo("Success", "MEMBER information added successfully!")
        except psycopg2.IntegrityError as e:
            if "unique constraint" in str(e):
                messagebox.showwarning("Warning", "GYM ID ALREADY EXISTS. ENTER A NEW ONE.")
            else:
                messagebox.showerror("Error", f"Error adding member information: {e}")

        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
def main():
    app = AddUser()
    app.mainloop()

if __name__ == "__main__":
    main()
