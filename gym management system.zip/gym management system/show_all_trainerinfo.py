import tkinter as tk
from tkinter import ttk, messagebox
import psycopg2
from PIL import ImageTk, Image


class AuthWindow:
    def __init__(self, master=None):
        self.master = master
        self.master.title("ADMIN Login")
        self.master.geometry("300x400")

        self.frame = tk.Frame(self.master, bg="#4026e2", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.pack()

        self.username_label = tk.Label(self.frame, text="Username:", font=("Arial", 20), bg="#f4f4f4", bd=6,
                                       relief=tk.RAISED)
        self.username_label.pack(pady=10)

        self.username_entry = tk.Entry(self.frame, width=12, font=("Arial", 30))
        self.username_entry.pack(pady=10)

        self.password_label = tk.Label(self.frame, text="Password:", font=("Arial", 20), bg="#f4f4f4", bd=6,
                                       relief=tk.RAISED)
        self.password_label.pack(pady=10)

        self.password_entry = tk.Entry(self.frame, show="*", width=12, font=("Arial", 30))
        self.password_entry.pack(pady=10)

        self.login_btn = tk.Button(self.frame, text="Login", command=self.login, width=25, height=2, bg="#f4f4f4",
                                   fg="black", bd=10, relief=tk.RAISED)
        self.login_btn.pack(pady=10)

        self.conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost",
                                     port="5432")
        self.cursor = self.conn.cursor()

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        # Fetch admin passwords from the database based on the entered username
        self.cursor.execute("SELECT password FROM loginpass WHERE username = %s", (username,))
        db_passwords = self.cursor.fetchall()

        if db_passwords:
            valid_passwords = [dbp[0] for dbp in db_passwords]
            if password in valid_passwords:
                messagebox.showinfo("Login Success", "Welcome, Admin!")
                # Open the view trainers info window
                gym_system.view_trainers_info_authenticated()
            else:
                messagebox.showerror("Login Failed", "Invalid password")
        else:
            messagebox.showerror("Login Failed", "Invalid username")


class GymManagementSystem:
    def __init__(self):
        self.conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost",
                                     port="5432")
        self.cursor = self.conn.cursor()

        # Create the main admin window
        self.admin_window = tk.Tk()
        self.admin_window.title("All Trainer Interface")

        # Create an instance of AuthWindow for authentication
        self.auth_window = AuthWindow(self.admin_window)

    def view_trainers_info_authenticated(self):
        # Destroy the authentication window
        self.auth_window.frame.destroy()

        # Create a Treeview widget for displaying the data in a table format

        self.tree = ttk.Treeview(self.admin_window,)
        self.tree["columns"] = ("Name", "Height", "Weight", "Experience", "Clients", "Hours Worked")
        self.tree.heading("#0", text="Trainer ID", anchor=tk.CENTER)
        self.tree.column("#0", width=150, anchor=tk.CENTER)
        for column in self.tree["columns"]:
            self.tree.heading(column, text=column, anchor=tk.CENTER)
            self.tree.column(column, width=150, anchor=tk.CENTER)

        # Fetch data from the database and insert into the Treeview widget
        self.cursor.execute(
            "SELECT trainer_id, name, height, weight, experience, clients, hours_worked FROM trainer_info")
        trainers_data = self.cursor.fetchall()
        for trainer in trainers_data:
            self.tree.insert("", "end", text=trainer[0],
                             values=(trainer[1], trainer[2], trainer[3], trainer[4], trainer[5], trainer[6]))

            self.admin_window.geometry("1920x1080")

        self.tree.pack()

    def run(self):
        self.admin_window.mainloop()


# Create an instance of the GymManagementSystem class and run the application
gym_system = GymManagementSystem()
gym_system.run()
