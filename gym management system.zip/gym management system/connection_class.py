#code2


import psycopg2

class ConnectionClass:
    def __init__(self):
        try:
            # Establishing connection to PostgreSQL database
            self.conn = psycopg2.connect(
                dbname="gym_db",
                user="postgres",
                password="Anish@534",
                host="localhost",
                port="5432"
            )
            self.cur = self.conn.cursor()
            print("Connected to PostgreSQL successfully!")
        except psycopg2.Error as e:
            print("Error connecting to PostgreSQL:", e)
            self.conn = None
            self.cur = None

    def close_connection(self):
        if self.conn:
            self.cur.close()
            self.conn.close()
            print("PostgreSQL connection is closed.")
        else:
            print("No active connection to close.")

def main():
    # Creating an instance of ConnectionClass to connect to PostgreSQL
    connection_obj = ConnectionClass()

    # Perform database operations here
    # Example:
    # if connection_obj.conn:
    #     connection_obj.cur.execute("SELECT * FROM members")
    #     rows = connection_obj.cur.fetchall()
    #     for row in rows:
    #         print(row)

    # Closing the connection
    connection_obj.close_connection()

if __name__ == "__main__":
    main()

