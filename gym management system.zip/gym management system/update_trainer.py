import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import psycopg2
import re
# Global variables for entry fields
name_entry = None
height_entry = None
weight_entry = None
experience_entry = None
clients_entry = None
hours_worked_entry = None
update_window = None

# Function to update trainer info in the database
def update_trainer_info(trainer_id):
    # Get values from entry fields
    new_name = name_entry.get()
    new_height = height_entry.get()
    new_weight = weight_entry.get()
    new_experience = experience_entry.get()
    new_clients = clients_entry.get()
    new_hours_worked = hours_worked_entry.get()

    # Input validation
    if not re.match(r'^[a-zA-Z\s]+$', new_name):
        messagebox.showerror("Error", "Please enter alphabets and spaces only for the name.")
        return
    try:
        new_height = int(new_height)
        new_weight = int(new_weight)
        new_experience = int(new_experience)
        new_clients = int(new_clients)
        new_hours_worked = int(new_hours_worked)
    except ValueError:
        messagebox.showerror("Error",
                             "Please enter integer values for height, weight, experience, clients, and hours worked.")
        return

    # Update trainer info in the database
    try:
        conn = psycopg2.connect(
            dbname="gym_db",
            user="postgres",
            password="Anish@534",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()

        update_query = "UPDATE trainer_info SET name=%s, height=%s, weight=%s, experience=%s, clients=%s, hours_worked=%s WHERE trainer_id=%s"
        cursor.execute(update_query,
                       (new_name, new_height, new_weight, new_experience, new_clients, new_hours_worked, trainer_id))

        conn.commit()
        conn.close()

        messagebox.showinfo("Success", "Trainer info updated")
        update_window.destroy()
        refresh_first_interface()

    except (Exception, psycopg2.Error) as error:
        print("Error updating trainer info:", error)

# Function to fetch trainer info from the database
def fetch_trainer_info(trainer_id):
    try:
        conn = psycopg2.connect(
            dbname="gym_db",
            user="postgres",
            password="Anish@534",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()

        select_query = "SELECT * FROM trainer_info WHERE trainer_id=%s"
        cursor.execute(select_query, (trainer_id,))
        trainer_info = cursor.fetchone()

        conn.close()
        return trainer_info

    except (Exception, psycopg2.Error) as error:
        print("Error fetching trainer info:", error)
        return None

# Function to refresh the first interface
def refresh_first_interface():
    global trainer_id_entry
    trainer_id_entry.delete(0, tk.END)

# Function to handle the first interface
def first_interface():
    global trainer_id_entry, update_window
    update_window = tk.Tk()
    update_window.title("Update Trainer Info")
    update_window.geometry("800x600")

    # Set background image
    bg_image = Image.open("logininterface.jpg")
    bg_image = bg_image.resize((1920, 1080))  # Resize the image to full screen
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label = tk.Label(update_window, image=bg_photo)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)

    # Add a frame for the labels
    frame = tk.Frame(bg_label, bg="#b3481c", bd=10, relief=tk.RAISED, padx=20, pady=20, highlightbackground="#f48d27")
    frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

    # Configure label
    label_text = "Enter Trainer ID:"
    label = tk.Label(frame, text=label_text, font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
    label.pack(pady=10)

    # Configure entry field
    trainer_id_entry = tk.Entry(frame, width=13, font=("Arial", 20))
    trainer_id_entry.pack(pady=10)

    # Configure submit button
    submit_button = tk.Button(frame, text="Submit", command=fetch_trainer_details)
    submit_button.config(width=20, height=3, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
    submit_button.pack(pady=10)

    update_window.mainloop()


# Function to handle the second interface
def second_interface(trainer_info):
    global name_entry, height_entry, weight_entry, experience_entry, clients_entry, hours_worked_entry, update_window, bg_photo_second

    update_window = tk.Toplevel()
    update_window.title("Update Trainer Info")
    update_window.geometry("1920x1080")

    # Set background image
    bg_image_second = Image.open("logininterface.jpg")
    bg_image_second = bg_image_second.resize((1920, 1080))
    bg_photo_second = ImageTk.PhotoImage(bg_image_second)
    bg_label_second = tk.Label(update_window, image=bg_photo_second)
    bg_label_second.place(x=0, y=0, relwidth=1, relheight=1)

    # Create a frame for the labels and entry fields
    frame = tk.Frame(bg_label_second, bg="#b3481c", bd=10, relief=tk.RAISED, padx=20, pady=20,
                     highlightbackground="#f48d27")
    frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

    # Define labels and entry fields
    labels = ["Name:", "Height:", "Weight:", "Experience:", "Clients:", "Hours worked:"]
    entries = [tk.Entry(frame, width=13, font=("Arial", 20)) for _ in range(6)]

    # Insert data into entry fields based on trainer_info
    for index, entry in enumerate(entries):
        entry.insert(0, trainer_info[index])

    # Add labels and entry fields to the grid
    for row, label_text in enumerate(labels):
        label = tk.Label(frame, text=label_text, font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
        label.grid(row=row, column=0, padx=10, pady=10, sticky=tk.W)
        entries[row].grid(row=row, column=1, padx=10, pady=10)

    # Assign entry fields to specific variables
    name_entry = entries[0]
    height_entry = entries[1]
    weight_entry = entries[2]
    experience_entry = entries[3]
    clients_entry = entries[4]
    hours_worked_entry = entries[5]

    # Add a submit button
    submit_button = tk.Button(frame, text="Update", command=lambda: update_trainer_info(trainer_info[6]))
    submit_button.config(width=20, height=2, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
    submit_button.grid(row=len(labels), columnspan=2, padx=10, pady=20)


# Function to fetch trainer details and switch to the second interface
def fetch_trainer_details():
    trainer_id = trainer_id_entry.get()
    trainer_info = fetch_trainer_info(trainer_id)

    if trainer_info:
        second_interface(trainer_info)
    else:
        messagebox.showerror("Error", "Trainer ID not found")

# Start with the first interface
first_interface()
