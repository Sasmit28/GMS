import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import psycopg2


class AttendanceViewer:
    def __init__(self, root):
        self.root = root
        self.root.title("Attendance Viewer")
        self.root.geometry("1920x1080")

        # Load the background image
        self.background_image = Image.open("att.png.jpg")
        self.background_photo = ImageTk.PhotoImage(self.background_image)

        # Create a label to hold the background image
        self.background_label = tk.Label(root, image=self.background_photo)
        self.background_label.place(relwidth=1, relheight=1)  # Fill the entire window

        # Create a treeview to display the data
        self.tree = ttk.Treeview(root, columns=("Date", "Gym ID", "Name", "Entry Time", "Exit Time"))
        self.tree.heading("#0", text="Index", anchor=tk.CENTER)
        self.tree.heading("Date", text="Date", anchor=tk.CENTER)
        self.tree.heading("Gym ID", text="Gym ID", anchor=tk.CENTER)
        self.tree.heading("Name", text="Name", anchor=tk.CENTER)
        self.tree.heading("Entry Time", text="Entry Time", anchor=tk.CENTER)
        self.tree.heading("Exit Time", text="Exit Time", anchor=tk.CENTER)

        # Set column alignment to center for all columns
        for col in self.tree["columns"]:
            self.tree.column(col, anchor=tk.CENTER)

        self.tree.pack(expand=True, fill="both")

        # Bind F5 key to refresh data
        root.bind("<F5>", self.refresh_data)

        # Connect to the PostgreSQL database
        try:
            self.connection = psycopg2.connect(
                database="gym_db",
                user="postgres",
                password="Anish@534",
                host="localhost",
                port="5432"
            )
            self.cursor = self.connection.cursor()
        except psycopg2.Error as e:
            print("Error connecting to PostgreSQL database:", e)

        # Fetch and display attendance data with member names in reverse order
        self.fetch_attendance_data(reverse=True)

    def fetch_attendance_data(self, reverse=False):
        try:
            # Joining members and attendance_records tables on gym_id
            self.cursor.execute("""
                SELECT a.entry_date, a.gym_id, m.name, a.entry_time, a.exit_time
                FROM attendance_records a
                JOIN members m ON a.gym_id = m.gymid
                ORDER BY a.entry_date DESC, a.entry_time DESC  -- Order by date and time in descending order
            """)
            attendance_data = self.cursor.fetchall()

            self.tree.delete(*self.tree.get_children())  # Clear existing data in the treeview

            if reverse:
                attendance_data = reversed(attendance_data)

            for idx, data in enumerate(attendance_data, start=1):
                self.tree.insert("", "end", iid=idx, values=data)
        except psycopg2.Error as e:
            print("Error fetching attendance data:", e)

    def refresh_data(self, event=None):
        self.fetch_attendance_data(reverse=True)  # Fetch and display data in reverse order

    def run(self):
        self.root.mainloop()



# Create the main window
root = tk.Tk()
app = AttendanceViewer(root)
app.run()
