import tkinter as tk
from PIL import Image, ImageTk
from tkinter import ttk
from login_interface import Login
import subprocess

class AdminLogin(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Admin Login")
        self.geometry("1920x1080")  # Set the width and height of the main window

        # Load the background image
        bg_image = Image.open("adminlogin.png")
        bg_photo = ImageTk.PhotoImage(bg_image)

        # Create a label to hold the background image
        self.bg_label = tk.Label(self, image=bg_photo)
        self.bg_label.image = bg_photo
        self.bg_label.pack(fill="both", expand=True)

        self.frame = tk.Frame(self.bg_label, bg="#292826", bd=10, relief=tk.RAISED,)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)  # Center the frame in the window

        # Buttons for trainer actions
        self.add_trainer_btn = tk.Button(self.frame, text="Add Trainer", command=self.open_add_trainer)
        self.style_button(self.add_trainer_btn)
        self.add_trainer_btn.grid(row=0, column=0, pady=10, padx=20)

        self.update_trainer_btn = tk.Button(self.frame, text="Update Trainer Info", command=self.open_update_trainer)
        self.style_button(self.update_trainer_btn)
        self.update_trainer_btn.grid(row=1, column=0, pady=10, padx=20)

        self.delete_trainer_btn = tk.Button(self.frame, text="Delete Trainer", command=self.open_delete_trainer)
        self.style_button(self.delete_trainer_btn)
        self.delete_trainer_btn.grid(row=2, column=0, pady=10, padx=20)

        self.show_trainer_btn = tk.Button(self.frame, text="Show Trainer Info", command=self.open_show_trainer)
        self.style_button(self.show_trainer_btn)
        self.show_trainer_btn.grid(row=3, column=0, pady=10, padx=20)

        # Buttons for member actions
        self.add_member_btn = tk.Button(self.frame, text="Add Member", command=self.open_add_member)
        self.style_button(self.add_member_btn)
        self.add_member_btn.grid(row=0, column=1, pady=10, padx=20)

        self.update_member_btn = tk.Button(self.frame, text="Update Member Info", command=self.open_update_member)
        self.style_button(self.update_member_btn)
        self.update_member_btn.grid(row=1, column=1, pady=10, padx=20)

        self.delete_member_btn = tk.Button(self.frame, text="Delete Member", command=self.open_delete_member)
        self.style_button(self.delete_member_btn)
        self.delete_member_btn.grid(row=2, column=1, pady=10, padx=20)

        self.show_member_btn = tk.Button(self.frame, text="Show Member Info", command=self.open_show_member)
        self.style_button(self.show_member_btn)
        self.show_member_btn.grid(row=3, column=1, pady=10, padx=20)

        self.show_all_trainer = tk.Button(self.frame, text="Show All Trainer Info", command=self.open_all_show_trainer)
        self.style_button(self.show_all_trainer)
        self.show_all_trainer.grid(row=4, column=0, pady=10, padx=20)

        self.show_all_member = tk.Button(self.frame, text="Show All Member Info", command=self.open_all_show_member)
        self.style_button(self.show_all_member)
        self.show_all_member.grid(row=4, column=1, pady=10, padx=20)

        # Logout button
        self.logout_btn = tk.Button(self.frame, text="Logout", command=self.logout)
        self.style_button(self.logout_btn)
        self.logout_btn.grid(row=5, columnspan=2, pady=20, padx=20)

    def style_button(self, button):
        button.config(width=25, height=4, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED,font=("Arial", 13))

    def open_add_member(self):
        subprocess.Popen(['python', 'add_user.py'])

    def open_update_member(self):
        subprocess.Popen(['python', 'update_members.py'])

    def open_show_member(self):
        subprocess.Popen(['python', 'show_user_info.py'])

    def open_delete_member(self):
        subprocess.Popen(['python', 'delete_member.py'])

    def open_add_trainer(self):
        subprocess.Popen(['python', 'add_trainer.py'])

    def open_update_trainer(self):
        subprocess.Popen(['python', 'update_trainer.py'])

    def open_show_trainer(self):
        subprocess.Popen(['python', 'show_trainer_info.py'])

    def open_delete_trainer(self):
        subprocess.Popen(['python', 'delete_trainer.py'])

    def open_all_show_trainer(self):
        subprocess.Popen(['python', 'show_all_trainerinfo.py'])

    def open_all_show_member(self):
        subprocess.Popen(['python', 'show_member_info.py'])



    def logout(self):
        self.destroy()
        login_window = Login()
        login_window.mainloop()

def main():
    app = AdminLogin()
    app.mainloop()

if __name__ == "__main__":
    main()
