import tkinter as tk
from tkinter import messagebox
import psycopg2
from PIL import ImageTk,Image

class DeleteTrainerGUI:
    def __init__(self, master):
        self.master = master
        self.master.geometry("500x400")
        self.master.title("Delete Trainer")

        bg_image = Image.open("logininterface.jpg")
        bg_image = bg_image.resize((1920, 1080))
        self.bg_photo_main = ImageTk.PhotoImage(bg_image)
        bg_label_main = tk.Label(self.master, image=self.bg_photo_main)
        bg_label_main.place(x=0, y=0, relwidth=1, relheight=1)

        self.frame = tk.Frame(bg_label_main, bg="#b3481c", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        self.label_id = tk.Label(self.frame, text="Enter Trainer ID to Delete Trainer", font=("Arial", 20), bg="#f4f4f4", bd=6,
                                 relief=tk.RAISED)
        self.label_id.pack(pady=10)

        self.entry_id = tk.Entry(self.frame, width=12, font=("Arial", 30))
        self.entry_id.pack(pady=10)

        self.submit_button = tk.Button(self.frame, text="SUBMIT", command=self.delete_trainer, width=25, height=4,
                                       bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
        self.submit_button.pack(pady=10)


        self.bg_image = bg_image  # Save reference to avoid garbage collection

    def delete_trainer(self):
        trainer_id = self.entry_id.get()

        try:
            conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost", port="5432")
            cursor = conn.cursor()

            delete_query = f"DELETE FROM trainer_info WHERE trainer_id = %s"
            cursor.execute(delete_query, (trainer_id,))

            if cursor.rowcount == 0:
                # Trainer with the given ID does not exist
                messagebox.showinfo("Trainer Not Found", "No trainer found with the provided ID.")
            else:
                conn.commit()
                messagebox.showinfo("Success", "Trainer deleted successfully!")
                self.master.destroy()

            cursor.close()
            conn.close()

        except psycopg2.Error as e:
            # Check if the error indicates that the trainer does not exist
            error_message = str(e)
            if "violates foreign key constraint" in error_message:
                messagebox.showinfo("Trainer Not Found", "No trainer found with the provided ID.")
            else:
                messagebox.showerror("Error", f"Error deleting trainer: {e}")

def main():
    root = tk.Tk()
    app = DeleteTrainerGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
