import tkinter as tk
from admin_login import AdminLogin

def main():
    root = tk.Tk()
    app = AdminLogin()  # Create an instance of AdminLogin without passing any arguments
    root.mainloop()

if __name__ == "__main__":
    main()

