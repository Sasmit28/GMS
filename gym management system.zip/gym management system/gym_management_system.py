import tkinter as tk

class GymManagementSystem:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("ADMIN/USER")

        self.frame = tk.Frame(self.root)
        self.frame.pack()

        self.l1 = tk.Label(self.frame)
        self.l1.place(x=0, y=0, width=580, height=350)

       #image to add image to gymmanagememtsystem

        self.bt1 = tk.Button(self.frame, text="ADMIN", command=self.login_as_admin)
        self.bt1.place(x=120, y=220, width=150, height=40)

        self.bt2 = tk.Button(self.frame, text="USER", command=self.login_as_user)
        self.bt2.place(x=320, y=220, width=150, height=40)

        self.l3 = tk.Label(self.frame, text="Login as Admin or User", font=("arial", 30, "bold"), fg="dark gray")
        self.l3.place(x=125, y=100)

    def login_as_admin(self):
        self.root.withdraw()  # Hide the current window
        AdminLogin()

    def login_as_user(self):
        self.root.withdraw()  # Hide the current window
        UserInfo()

class AdminLogin:
    def __init__(self):
        self.admin_window = tk.Toplevel()
        self.admin_window.title("ADMIN Login")
        # Add your admin login GUI elements here

class UserInfo:
    def __init__(self):
        self.user_window = tk.Toplevel()
        self.user_window.title("USER Info")
        # Add your user info GUI elements here

def main():
    app = GymManagementSystem()
    app.root.geometry("600x400")
    app.root.mainloop()

if __name__ == "__main__":
    main()
