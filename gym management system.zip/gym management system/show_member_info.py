import tkinter as tk
from tkinter import ttk, messagebox
import psycopg2

class AuthWindow:
    def __init__(self, master=None):
        self.master = master
        self.master.title("ADMIN Login")
        self.master.geometry("300x400")

        self.frame = tk.Frame(self.master, bg="#4026e2", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.pack()

        self.username_label = tk.Label(self.frame, text="Username:", font=("Arial", 20), bg="#f4f4f4", bd=6,
                                       relief=tk.RAISED)
        self.username_label.pack(pady=10)

        self.username_entry = tk.Entry(self.frame, width=12, font=("Arial", 30))
        self.username_entry.pack(pady=10)

        self.password_label = tk.Label(self.frame, text="Password:", font=("Arial", 20), bg="#f4f4f4", bd=6,
                                       relief=tk.RAISED)
        self.password_label.pack(pady=10)

        self.password_entry = tk.Entry(self.frame, show="*", width=12, font=("Arial", 30))
        self.password_entry.pack(pady=10)

        self.login_btn = tk.Button(self.frame, text="Login", command=self.login, width=25, height=2, bg="#f4f4f4",
                                   fg="black", bd=10, relief=tk.RAISED)
        self.login_btn.pack(pady=10)

        self.conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost",
                                     port="5432")
        self.cursor = self.conn.cursor()

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        # Fetch admin passwords from the database based on the entered username
        self.cursor.execute("SELECT password FROM loginpass WHERE username = %s", (username,))
        db_passwords = self.cursor.fetchall()

        if db_passwords:
            valid_passwords = [dbp[0] for dbp in db_passwords]
            if password in valid_passwords:
                messagebox.showinfo("Login Success", "Welcome, Admin!")
                # Open the view members info window
                gym_system.view_members_info_authenticated()
            else:
                messagebox.showerror("Login Failed", "Invalid password")
        else:
            messagebox.showerror("Login Failed", "Invalid username")


class GymManagementSystem:
    def __init__(self):
        self.conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost",
                                     port="5432")
        self.cursor = self.conn.cursor()

        # Create the main admin window
        self.admin_window = tk.Tk()
        self.admin_window.title("All Members Interface")


        # Create an instance of AuthWindow for authentication
        self.auth_window = AuthWindow(self.admin_window)

    def view_members_info_authenticated(self):
        # Destroy the authentication window
        self.auth_window.frame.destroy()

        # Create a Treeview widget for displaying the member data in a table format
        self.tree_members = ttk.Treeview(self.admin_window)
        self.tree_members["columns"] = (
            "Name", "Height", "Weight", "Body Fat", "Membership Type", "Contact Number", "DOB", "Occupation",
            "Email", "Account Status", "Registration Date", "Expiry Date")
        self.tree_members.heading("#0", text="Gym ID", anchor=tk.CENTER)
        self.tree_members.column("#0", width=150, anchor=tk.CENTER)
        for column in self.tree_members["columns"]:
            self.tree_members.heading(column, text=column, anchor=tk.CENTER)
            self.tree_members.column(column, width=150, anchor=tk.CENTER)

        # Fetch data from the members table and insert into the Treeview widget
        self.cursor.execute(
            "SELECT gymid, name, height, weight, bodyfat, membershiptype, contact_number, dob, occupation, email, "
            "account_status, reg_date, expiry_date FROM members")
        members_data = self.cursor.fetchall()
        for member in members_data:
            self.tree_members.insert("", "end", text=member[0],
                                      values=(
                                      member[1], member[2], member[3], member[4], member[5], member[6], member[7],
                                      member[8], member[9], member[10], member[11], member[12]))
            self.admin_window.geometry("1920x1080")

        self.tree_members.pack()

    def run(self):
        self.admin_window.mainloop()


# Create an instance of the GymManagementSystem class and run the application
gym_system = GymManagementSystem()
gym_system.run()
