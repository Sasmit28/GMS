import tkinter as tk
from tkinter import messagebox
import psycopg2
from PIL import Image, ImageTk

class DeleteMemberGUI:
    def __init__(self, master):
        self.master = master
        self.master.geometry("500x400")
        self.master.title("Delete Member")

        bg_image = Image.open("logininterface.jpg")
        bg_image = bg_image.resize((1920, 1080))
        self.bg_photo_main = ImageTk.PhotoImage(bg_image)
        bg_label_main = tk.Label(self.master, image=self.bg_photo_main)
        bg_label_main.place(x=0, y=0, relwidth=1, relheight=1)

        self.frame = tk.Frame(bg_label_main, bg="#b3481c", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)


        self.label_id = tk.Label(self.frame, text="Enter member ID to delete:",  font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
        self.label_id.pack(pady=10)

        self.entry_id = tk.Entry(self.frame,width=12, font=("Arial", 30))
        self.entry_id.pack(pady=10)

        self.submit_button = tk.Button(self.frame, text="SUBMIT", command=self.confirm_delete,width=25, height=4, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
        self.submit_button.pack(pady=10)

        self.bg_image = bg_image  # Save reference to avoid garbage collection

    def confirm_delete(self):
        member_id = self.entry_id.get()

        if not member_id:
            messagebox.showwarning("Incomplete Information", "Please enter member ID.")
            return

        try:
            conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost",
                                    port="5432")
            cursor = conn.cursor()

            # Check if member ID exists
            check_query = "SELECT * FROM members WHERE gymid = %s"
            cursor.execute(check_query, (member_id,))
            member_data = cursor.fetchone()

            if member_data is None:
                messagebox.showerror("Invalid Gym ID", "No member found with the provided ID.")
            else:
                # Delete member
                delete_query = "DELETE FROM members WHERE gymid = %s"
                cursor.execute(delete_query, (member_id,))
                conn.commit()
                messagebox.showinfo("Success", "Member deleted successfully!")
                self.clear_entries()  # Clear entries after deletion

            cursor.close()
            conn.close()

        except psycopg2.Error as e:
            messagebox.showerror("Error", f"Error deleting member: {e}")

    def clear_entries(self):
        self.entry_id.delete(0, tk.END)

def main():
    root = tk.Tk()
    app = DeleteMemberGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
