import tkinter as tk
from tkinter import messagebox
import psycopg2
from datetime import datetime, timedelta
from PIL import Image, ImageTk

# Function to calculate new expiry date based on membership type
def calculate_expiry_date(old_expiry_date, membership_type):
    if membership_type == 'Monthly':
        new_expiry_date = old_expiry_date + timedelta(days=30)
    elif membership_type == 'Yearly':
        new_expiry_date = old_expiry_date + timedelta(days=365)
    elif membership_type == 'Quarterly':
        new_expiry_date = old_expiry_date + timedelta(days=90)
    elif membership_type == 'Half-yearly':
        new_expiry_date = old_expiry_date + timedelta(days=182)
    else:
        new_expiry_date = None
    return new_expiry_date

# Function to renew membership and update the expiry date in the second window
def renew_membership():
    gym_id = gym_id_entry.get()
    membership_type = membership_type_var.get()
    payment_method = payment_method_var.get()

    if membership_type not in ['Monthly', 'Yearly', 'Quarterly', 'Half-yearly']:
        messagebox.showerror('Error', 'Invalid membership type selected.')
        return

    # Connect to the database
    conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost", port="5432")
    cursor = conn.cursor()

    # Fetch membership info from 'members' table based on gym ID
    cursor.execute("SELECT reg_date, expiry_date, membershiptype FROM members WHERE gymid = %s", (gym_id,))
    membership_info = cursor.fetchone()

    if membership_info:
        reg_date, old_expiry_date, old_membership_type = membership_info

        if old_membership_type != membership_type:
            new_expiry_date = calculate_expiry_date(old_expiry_date, membership_type)
        else:
            new_expiry_date = old_expiry_date

        if new_expiry_date is not None:
            # Update expiry date and membership type in 'members' table
            cursor.execute("UPDATE members SET expiry_date = %s, membershiptype = %s WHERE gymid = %s",
                           (new_expiry_date, membership_type, gym_id))

            # Insert renewal entry in 'renewal_table'
            renewal_date = datetime.now().date()
            cursor.execute("INSERT INTO renewal_table (gym_id, renewal_date, payment_method) VALUES (%s, %s, %s)",
                           (gym_id, renewal_date, payment_method))

            conn.commit()

            conn.close()

            # Update expiry date label in the second window
            expiry_date_label.config(text=f'Expiry Date: {new_expiry_date}')

            messagebox.showinfo('Success', 'Membership renewed successfully!')
        else:
            messagebox.showerror('Error', 'Invalid membership type selected.')
    else:
        messagebox.showerror('Error', 'Member with this Gym ID not found.')

# Function to update expiry date label in the second window
def update_expiry_date():
    gym_id = gym_id_entry.get()

    # Connect to the database
    conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost", port="5432")
    cursor = conn.cursor()

    # Fetch updated expiry date from the database
    cursor.execute("SELECT expiry_date FROM members WHERE gymid = %s", (gym_id,))
    updated_expiry_date = cursor.fetchone()[0]

    conn.close()

    # Update expiry date label in the second window
    expiry_date_label.config(text=f'Expiry Date: {updated_expiry_date}')

# Function to search for a member based on Gym ID
def search_member():
    gym_id = gym_id_entry.get()

    # Connect to the database
    conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost", port="5432")
    cursor = conn.cursor()

    # Fetch membership info from 'members' table based on gym ID
    cursor.execute("SELECT reg_date, expiry_date, membershiptype FROM members WHERE gymid = %s", (gym_id,))
    membership_info = cursor.fetchone()

    if membership_info:
        reg_date, expiry_date, membership_type = membership_info

        # Hide first window
        first_window.withdraw()

        # Show the second window for renewal
        second_window.deiconify()

        # Display reg_date and expiry_date in second window
        reg_date_label.config(text=f'Registration Date: {reg_date}')
        expiry_date_label.config(text=f'Expiry Date: {expiry_date}')

        # Set the default membership type in the dropdown menu
        membership_type_var.set(membership_type)

    else:
        messagebox.showerror('Error', 'Member with this Gym ID not found.')

    conn.close()

# Create Tkinter window for first interface
first_window = tk.Tk()
first_window.title('Renew Membership')
first_window.title('Renew Membership')
first_window.geometry("600x400")

# Set background image for first window
bg_image = Image.open("att.png.jpg")
bg_photo = ImageTk.PhotoImage(bg_image)
bg_label = tk.Label(first_window, image=bg_photo)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

frame = tk.Frame(bg_label, bg="#4026e2", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)


# Interface elements for first window
gym_id_label = tk.Label(frame, text='Enter Gym ID:',font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
gym_id_label.pack(pady=10)
gym_id_entry = tk.Entry(frame,width=8,font=("Arial", 30))
gym_id_entry.pack(pady=10)
search_button = tk.Button(frame, text='Search',font=("Arial",14), command=search_member,width=15, height=1, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
search_button.pack(pady=10)

# Create second interface for membership renewal
second_window = tk.Toplevel(first_window)
second_window.title('Renew Membership')
second_window.geometry("600x500")
second_window.withdraw()  # Hide the second window initially



# Set background image for second window
bg_image_popup = Image.open("att.png.jpg")
bg_image_popup = bg_image_popup.resize((800,600))
bg_photo_popup = ImageTk.PhotoImage(bg_image_popup)


bg_label_second = tk.Label(second_window, image=bg_photo_popup)
bg_label_second.place(x=0, y=0, relwidth=1, relheight=1)


frame1 = tk.Frame(bg_label_second, bg="#4026e2", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
frame1.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

# Interface elements for second window
reg_date_label = tk.Label(frame1, text='',font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
reg_date_label.pack(pady=10)
expiry_date_label = tk.Label(frame1, text='', font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
expiry_date_label.pack()

membership_type_label = tk.Label(frame1, text='Select Membership Type:', font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
membership_type_label.pack(pady=10)
membership_types = ['Monthly', 'Yearly', 'Quarterly', 'Half-yearly']  # Add other membership types as needed
membership_type_var = tk.StringVar()
membership_type_dropdown = tk.OptionMenu(frame1, membership_type_var, *membership_types)
membership_type_dropdown.config(width=20, font=("Arial", 14))
membership_type_dropdown.pack(pady=10)

payment_method_label = tk.Label(frame1, text='Select Payment Method:', font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
payment_method_label.pack(pady=10)
payment_methods = ['Credit Card', 'Debit Card', 'Cash']  # Add other payment methods as needed
payment_method_var = tk.StringVar()
payment_method_dropdown = tk.OptionMenu(frame1, payment_method_var, *payment_methods)
payment_method_dropdown.config(width=20, font=("Arial", 14))
payment_method_dropdown.pack()

renew_button = tk.Button(frame1, text='Renew Membership', command=renew_membership,width=20, height=2, font=("Arial", 12),bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
renew_button.pack(pady=10)

first_window.mainloop()
