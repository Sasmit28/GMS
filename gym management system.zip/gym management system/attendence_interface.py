import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import datetime
import psycopg2

class GymManagementSystem(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Gym Management System")
        self.geometry("600x400")

        # Load the background image
        bg_image = Image.open("att.png.jpg")
        bg_image = bg_image.resize((600, 400))
        self.bg_photo = ImageTk.PhotoImage(bg_image)


        # Create a label to hold the background image and place it on the window
        self.bg_label = tk.Label(self, image=self.bg_photo)
        self.bg_label.pack(fill="both", expand=True)  # Fill the entire window with the image

        # Initialize database connection
        try:
            self.conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost", port="5432")
            self.cursor = self.conn.cursor()
        except psycopg2.Error as e:
            messagebox.showerror("Error", f"Failed to connect to the database: {e}")
            self.destroy()
            raise SystemExit

        # Create entry fields and buttons on or over the background image
        self.create_widgets()

        # Dictionary to store entry count and last entry time for each gym ID
        self.entry_info = {}

        # Bind Enter key to login process
        self.bind("<Return>", lambda event: self.login_process())
        self.bind("<Delete>", lambda event: self.logout_process())
        self.bind("<Shift-Return>", lambda event: self.logout_process())

    def create_widgets(self):

        self.frame = tk.Frame(self.bg_label, bg="#4026e2", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)


        # Create entry fields and buttons on or over the background image
        self.gym_id_label = tk.Label(self.frame, text="Enter Gym ID:", font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
        self.gym_id_label.pack(pady=10)

        self.gym_id_entry = tk.Entry(self.frame,width=8,font=("Arial", 30))
        self.gym_id_entry.pack(pady=10)

        self.login_button = tk.Button(self.frame, text="Login", command=self.login_process, width=20, height=2, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
        self.login_button.pack(pady=10)

        self.logout_button = tk.Button(self.frame, text="Logout", command=self.logout_process, width=20, height=2, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
        self.logout_button.pack(pady=10)

    def login_process(self):
        gym_id = self.gym_id_entry.get().strip()  # Remove leading/trailing spaces

        if not gym_id:  # Check if gym ID is empty
            messagebox.showerror("Error", "Please enter Gym ID.")
            return

        current_date = datetime.datetime.now().date()  # Get current date

        try:
            # Check if gym ID exists in the members table
            self.cursor.execute(f"SELECT gymid FROM members WHERE gymid='{gym_id}'")
            gym_exists = self.cursor.fetchone()

            if gym_exists:
                if gym_id in self.entry_info and self.entry_info[gym_id]['date'] == current_date:
                    # If already logged in today, show error message
                    messagebox.showinfo("Alert", "You have already logged in today.")
                else:
                    # Insert entry record into database
                    entry_time = datetime.datetime.now()
                    insert_query = f"INSERT INTO attendance_records (gym_id, entry_time, entry_date) VALUES ('{gym_id}', '{entry_time}', '{current_date}')"
                    self.cursor.execute(insert_query)
                    self.conn.commit()

                    self.entry_info[gym_id] = {'date': current_date, 'entry_time': entry_time}

                    messagebox.showinfo("Success", "Logged in successfully!")
            else:
                # Gym ID not found in members table
                messagebox.showerror("Error", "Please enter a valid Gym ID.")
        except psycopg2.errors.UniqueViolation as e:
            self.conn.rollback()  # Rollback the transaction
            messagebox.showinfo("Alert", "GYM TIME OVER FOR TODAY\nVISIT TOMORROW")
        except psycopg2.Error as e:
            self.conn.rollback()  # Rollback the transaction
            messagebox.showerror("Error", f"Failed to log in: {e}")

    def logout_process(self, event=None):
        gym_id = self.gym_id_entry.get().strip()  # Remove leading/trailing spaces

        if not gym_id:  # Check if gym ID is empty
            messagebox.showerror("Error", "Please enter Gym ID.")
            return

        current_date = datetime.datetime.now().date()  # Get current date
        current_time = datetime.datetime.now().time()  # Get current time

        try:
            if gym_id not in self.entry_info or self.entry_info[gym_id]['date'] != current_date:
                # If not logged in today, show error message
                messagebox.showinfo("Alert", "You are not logged in today.")
            else:
                # Check if it's past 11 PM
                if current_time >= datetime.time(23, 0, 0):
                    exit_time = datetime.datetime.combine(current_date, datetime.time(23, 0, 0))
                else:
                    exit_time = datetime.datetime.now()

                duration_seconds = (exit_time - self.entry_info[gym_id]['entry_time']).total_seconds()  # Duration in seconds

                # Update exit time and duration in the database
                update_query = f"UPDATE attendance_records SET exit_time='{exit_time}', duration={duration_seconds} WHERE gym_id='{gym_id}' AND entry_date='{current_date}'"
                self.cursor.execute(update_query)
                self.conn.commit()

                del self.entry_info[gym_id]  # Remove entry info for the gym ID

                messagebox.showinfo("Success", f"Logged out successfully!\nDuration: {duration_seconds} seconds")
        except psycopg2.Error as e:
            self.conn.rollback()  # Rollback the transaction
            messagebox.showerror("Error", f"Failed to log out: {e}")

    def __del__(self):
        # Close the database connection when the window is destroyed
        self.cursor.close()
        self.conn.close()

if __name__ == "__main__":
    app = GymManagementSystem()
    app.mainloop()
