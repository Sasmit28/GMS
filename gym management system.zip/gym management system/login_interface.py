import tkinter as tk
from PIL import Image, ImageTk
from tkinter import messagebox
import psycopg2


class Login(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Login")
        self.geometry("1920x1080")

        # Load and display background image (assuming you have a background image named 'logininterface.jpg')
        bg_image = Image.open("logininterface.jpg")
        bg_image = bg_image.resize((1920, 1080))  # Resize the image to fit the window size
        bg_photo = ImageTk.PhotoImage(bg_image)
        self.bg_label = tk.Label(self, image=bg_photo)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)

        self.frame = tk.Frame(self.bg_label, bg="#b3481c", bd=10, relief=tk.RAISED, padx=20, pady=20)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        self.label = tk.Label(self.frame, text="Select User Type", font=("Arial", 20), bg="#f4f4f4", bd=6,
                              relief=tk.RAISED)
        self.label.pack(pady=10)

        self.admin_btn = tk.Button(self.frame, text="Admin Login", command=self.admin_login, font=("Arial", 14),
                                   bg="black", fg="white")
        self.admin_btn.pack(pady=10)

        self.user_btn = tk.Button(self.frame, text="User Login", command=self.user_login, font=("Arial", 14))
        self.user_btn.pack(pady=10)

        self.bg_photo = bg_photo  # Save reference to avoid garbage collection

        # Configure all buttons
        for widget in self.frame.winfo_children():
            if isinstance(widget, tk.Button):
                widget.config(width=25, height=4, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)

    # Remaining code for admin_login, user_login, and other classes...



    def admin_login(self):
        self.withdraw()  # Hide the login window
        admin_login_window = AdminLogin(self)
        admin_login_window.mainloop()

    def user_login(self):
        self.withdraw()  # Hide the login window
        user_login_window = UserLogin()
        user_login_window.mainloop()

class AdminLogin(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("ADMIN Login")
        self.geometry("300x400")


        self.frame = tk.Frame(self,bg="#4026e2", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.pack()

        self.username_label = tk.Label(self.frame, text="Username:",font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
        self.username_label.pack(pady=10)

        self.username_entry = tk.Entry(self.frame,width=12, font=("Arial", 30))
        self.username_entry.pack(pady=10)

        self.password_label = tk.Label(self.frame, text="Password:",font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
        self.password_label.pack(pady=10)

        self.password_entry = tk.Entry(self.frame, show="*",width=12, font=("Arial", 30))
        self.password_entry.pack(pady=10)

        self.login_btn = tk.Button(self.frame, text="Login", command=self.login,width=25, height=2, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
        self.login_btn.pack(pady=10)

        self.conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost",
                                    port="5432")
        self.cursor = self.conn.cursor()

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        # Fetch admin passwords from the database based on the entered username
        self.cursor.execute("SELECT password FROM loginpass WHERE username = %s", (username,))
        db_passwords = self.cursor.fetchall()

        if db_passwords:
            valid_passwords = [dbp[0] for dbp in db_passwords]
            if password in valid_passwords:
                messagebox.showinfo("Login Success", "Welcome, Admin!")
                self.destroy()  # Close the admin login window after successful login
                # Open your existing admin interface
                import subprocess
                subprocess.Popen(['python', 'admin_login.py'])
            else:
                messagebox.showerror("Login Failed", "Invalid password")
        else:
            messagebox.showerror("Login Failed", "Invalid username")

    def back_to_login(self):
        self.destroy()  # Close the admin login window
        login_window = Login()
        login_window.mainloop()

class UserLogin(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("User Login")
        self.geometry("300x400")

        self.frame = tk.Frame(self, bg="#4026e2", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.pack()

        self.username_label = tk.Label(self.frame, text="Username:", font=("Arial", 20), bg="#f4f4f4", bd=6,
                                       relief=tk.RAISED)
        self.username_label.pack(pady=10)

        self.username_entry = tk.Entry(self.frame, width=12, font=("Arial", 30))
        self.username_entry.pack(pady=10)

        self.password_label = tk.Label(self.frame, text="Password:", font=("Arial", 20), bg="#f4f4f4", bd=6,
                                       relief=tk.RAISED)
        self.password_label.pack(pady=10)

        self.password_entry = tk.Entry(self.frame, show="*", width=12, font=("Arial", 30))
        self.password_entry.pack(pady=10)

        self.login_btn = tk.Button(self.frame, text="Login", command=self.login, width=25, height=2, bg="#f4f4f4",
                                   fg="black", bd=10, relief=tk.RAISED)
        self.login_btn.pack(pady=10)


        self.conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost",
                                    port="5432")
        self.cursor = self.conn.cursor()



    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        # Fetch user password from the database based on the entered username
        self.cursor.execute("SELECT password FROM loginpass1 WHERE username = %s", (username,))
        db_password = self.cursor.fetchone()

        if db_password:
            if password == db_password[0]:
                messagebox.showinfo("Login Success", "Welcome, User!")
                self.destroy()  # Close the login window after successful login
                # Open your existing user interface
                import subprocess
                subprocess.Popen(['python', 'user_login_interface.py'])  # Call the main function of your user interface
            else:
                messagebox.showerror("Login Failed", "Invalid password")
        else:
            messagebox.showerror("Login Failed", "Invalid username")

    def back_to_login(self):
        self.destroy()  # Close the user login window
        login_window = Login()
        login_window.mainloop()

def main():
    login_window = Login()
    login_window.mainloop()

if __name__ == "__main__":
    main()
