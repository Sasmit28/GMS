import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import psycopg2
import re

class EnterGymID(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ENTER GYM ID")
        self.geometry("800x600")

        # Load and display background image (assuming you have a background image named 'logininterface.jpg')
        self.bg_image = Image.open("logininterface.jpg")
        self.bg_image = self.bg_image.resize((1920, 1080))  # Resize the image to full screen
        self.bg_photo = ImageTk.PhotoImage(self.bg_image)
        self.bg_label = tk.Label(self, image=self.bg_photo)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)

        self.frame = tk.Frame(self.bg_label, bg="#b3481c", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        self.label = tk.Label(self.frame, text="Enter Gym ID:", font=("Arial", 20), bg="#f4f4f4", bd=6,
                              relief=tk.RAISED)
        self.label.pack(pady=10)

        self.gymid_entry = tk.Entry(self.frame, width=25, font=("Arial", 20))
        self.gymid_entry.pack()

        self.submit_btn = tk.Button(self.frame, text='SUBMIT', font=("Arial", 12), width=25, height=2, bg="#f4f4f4",
                                    fg="black", bd=10, relief=tk.RAISED,command=self.open_member_interface)
        self.submit_btn.pack(pady=20)

        self.bind('<Return>', self.enter_pressed)  # Bind Enter key press event

    def enter_pressed(self, event):
        self.open_member_interface()

    def open_member_interface(self):
        gym_id = self.gymid_entry.get()
        if gym_id:
            member_interface = MemberInterface(gym_id, self)
            if member_interface.winfo_exists():  # Check if the window exists before grabbing
                member_interface.grab_set()  # Prevent interaction with main window
                self.gymid_entry.delete(0, tk.END)  # Clear the entry field
        else:
            messagebox.showwarning("Input Error", "Please enter a Gym ID.")


class MemberInterface(tk.Toplevel):
    def __init__(self, gym_id, parent):
        super().__init__(parent)
        self.title("UPDATE MEMBER INFO")
        self.geometry("1920x1080")

        self.bg_image = Image.open("logininterface.jpg")
        self.bg_image = self.bg_image.resize((1920, 1080))  # Resize the image to full screen
        self.bg_photo = ImageTk.PhotoImage(self.bg_image)
        self.bg_label = tk.Label(self, image=self.bg_photo)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)

        self.gym_id = gym_id
        self.parent = parent

        try:
            conn = psycopg2.connect(
                dbname="gym_db",
                user="postgres",
                password="Anish@534",
                host="localhost",
                port="5432"
            )
            cur = conn.cursor()
            cur.execute("SELECT * FROM members WHERE gymid = %s", (gym_id,))
            member_data = cur.fetchone()
            conn.close()
        except psycopg2.Error as e:
            messagebox.showerror("Database Error", f"Error fetching member information: {e}")
            self.destroy()  # Close the window on database error

        if member_data:
            self.display_member_info(member_data)
        else:
            messagebox.showerror("Data Error", "Member data not found.")
            self.destroy()  # Close the window if member data is not found

    def display_member_info(self, member_data):
        self.frame = tk.Frame(self.bg_label, bg="#b3481c", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)


        self.label = tk.Label(self.frame, text=f"Update Information for Member ID: {self.gym_id}", font=("Arial", 20),
                              bg="#f4f4f4", bd=6, relief=tk.RAISED)
        self.label.grid(row=0, column=0, columnspan=2, padx=10, pady=10)  # Grid layout for the main label

        fields = [
            ("Name:", 1),
            ("Height (cm):", 2),
            ("Weight (kg):", 3),
            ("Body Fat (%):", 4),
            ("Contact Number:", 6),
            ("Date of Birth (YYYY-MM-DD):", 7),
            ("Occupation:", 8),
            ("Email:", 9),
        ]

        self.entry_widgets = []
        for label_text, index in fields:
            label = tk.Label(self.frame, text=label_text, font=("Arial", 20), bg="#f4f4f4", bd=6, relief=tk.RAISED)
            label.grid(row=index, column=0, padx=10, pady=10, sticky=tk.W)  # Grid layout for labels

            entry = tk.Entry(self.frame, width=35, font=("Arial", 14))
            entry.grid(row=index, column=1, padx=10, pady=10, sticky=tk.W)  # Grid layout for entry widgets
            entry.insert(0, member_data[index])
            self.entry_widgets.append(entry)

        membership_options = ["Monthly", "Yearly", "Half-yearly", "Quarterly"]
        status_options = ["Active", "Inactive"]

        self.membership_label = tk.Label(self.frame, text='MEMBERSHIP TYPE', font=("Arial", 20), bg="#f4f4f4", bd=6,
                                         relief=tk.RAISED)
        self.membership_label.grid(row=10, column=0, padx=10, pady=10,
                                   sticky=tk.W)  # Adjusted grid layout for membership label

        self.membership_var = tk.StringVar(self)
        self.membership_var.set(member_data[5])
        self.membership_dropdown = ttk.Combobox(self.frame,font=("Arial", 12), textvariable=self.membership_var, values=membership_options,width=30)
        self.membership_dropdown.grid(row=10, column=1, padx=10, pady=10,
                                      sticky=tk.W)  # Adjusted grid layout for membership dropdown

        self.status_label = tk.Label(self.frame, text='STATUS', font=("Arial", 20), bg="#f4f4f4", bd=6,
                                     relief=tk.RAISED)
        self.status_label.grid(row=11, column=0, padx=10, pady=10, sticky=tk.W)  # Adjusted grid layout for status label

        self.status_var = tk.StringVar(self)
        self.status_var.set(member_data[10])
        self.status_dropdown = ttk.Combobox(self.frame,font=("Arial", 12), textvariable=self.status_var, values=status_options,width=30)
        self.status_dropdown.grid(row=11, column=1, padx=10, pady=10,
                                  sticky=tk.W)  # Adjusted grid layout for status dropdown
        # Grid layout for status dropdown

        self.submit_btn = tk.Button(self.frame, text='SUBMIT', font=("Arial", 12), width=25, height=1, bg="#f4f4f4",
                                    fg="black", bd=10, relief=tk.RAISED, command=self.submit)
        self.submit_btn.grid(row=14, column=0, columnspan=2, padx=10, pady=20)
    def validate_contact_number(self, contact):
        return len(contact) == 10 and contact.isdigit()

    def validate_email(self, email):
        return "@" in email

    def submit(self):
        name = self.entry_widgets[0].get()
        height = self.entry_widgets[1].get()
        weight = self.entry_widgets[2].get()
        bodyfat = self.entry_widgets[3].get()
        contact = self.entry_widgets[4].get()
        dob = self.entry_widgets[5].get()
        occupation = self.entry_widgets[6].get()
        email = self.entry_widgets[7].get()

        membership_type = self.membership_var.get()
        account_status = self.status_var.get()

        if all((name, height, weight, bodyfat, contact, dob, occupation, email)):
            if not re.match(r'^[a-zA-Z\s]+$', name):
                messagebox.showwarning("Warning", "Name should contain alphabets.")
                return

            if not height.isdigit() or not weight.isdigit() or not bodyfat.isdigit() or not contact.isdigit():
                messagebox.showwarning("Warning", "Height, Weight, Body Fat, and Contact Number should be integers.")
                return



            if not self.validate_contact_number(contact):
                messagebox.showwarning("Input Error", "Please enter a valid Contact Number (10 digits).")
            elif not self.validate_email(email):
                messagebox.showwarning("Input Error", "Please enter a valid Email Address.")

            else:
                try:
                    conn = psycopg2.connect(
                        dbname="gym_db",
                        user="postgres",
                        password="Anish@534",
                        host="localhost",
                        port="5432"
                    )
                    cur = conn.cursor()
                    cur.execute("""
                            UPDATE members 
                            SET name = %s, height = %s, weight = %s, bodyfat = %s, contact_number = %s,
                                dob = %s, occupation = %s, email = %s, membershiptype = %s, account_status = %s
                            WHERE gymid = %s
                        """, (name, height, weight, bodyfat, contact, dob, occupation, email,
                              membership_type, account_status, self.gym_id))
                    conn.commit()
                    conn.close()
                    messagebox.showinfo("Success", "Member information updated successfully.")
                    self.parent.deiconify()  # Show the parent window again
                    self.destroy()  # Close the update window
                except psycopg2.Error as e:
                    messagebox.showerror("Database Error", f"Error updating member information: {e}")
        else:
            messagebox.showwarning("Input Error", "Please fill in all fields.")


if __name__ == "__main__":
    app = EnterGymID()
    app.mainloop()
