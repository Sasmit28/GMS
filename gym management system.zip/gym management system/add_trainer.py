from PIL import Image, ImageTk
import tkinter as tk
from tkinter import messagebox
import psycopg2
import re


class AddTrainer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ADD TRAINER")

        self.l1 = tk.Label(self)
        self.l1.place(x=0, y=0, width=800, height=600)  # Set the window size to 800x600

        # Load the background image
        bg_image = Image.open("add_interface.jpg")
        bg_image = bg_image.resize((1920, 1080))  # Resize the image to fit the window
        bg_photo = ImageTk.PhotoImage(bg_image)

        # Create a label to hold the background image
        self.bg_label = tk.Label(self, image=bg_photo)
        self.bg_label.image = bg_photo  # Keep a reference to avoid garbage collection
        self.bg_label.pack(fill="both", expand=True)  # Fill the entire window with the image

        self.frame = tk.Frame(self.bg_label, bg="#302f2b", bd=10, relief=tk.RAISED, padx=20, pady=20,
                              highlightbackground="#f48d27")
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        # Place the frame at the center of the window

        self.label_configs = {
            "font": ("Arial", 20),
            "bg": "#f4f4f4",
            "bd": 6,
            "relief": tk.RAISED,
        }

        # Labels and entry fields setup
        self.labels = ["NAME", "HEIGHT", "WEIGHT", "EXPERIENCE", "CLIENTS", "HOURS WORKED", "TRAINER ID"]
        self.entry_fields = []

        for i, label_text in enumerate(self.labels):
            label = tk.Label(self.frame, text=label_text, **self.label_configs)  # Create label widget
            label.grid(row=i, column=0, sticky="w", pady=10, padx=10)  # Use grid layout for labels
            entry = tk.Entry(self.frame, width=35, font=("Arial", 14))  # Create entry widget with increased width
            entry.grid(row=i, column=1, sticky="w", pady=10, padx=10)  # Use grid layout for entry fields
            self.entry_fields.append(entry)

        # Button with custom configuration
        self.bt1 = tk.Button(self.frame, text="ADD INFO", command=self.add_trainer_info,
                             width=25, height=4, bg="#f4f4f4", fg="black", bd=10, relief=tk.RAISED)
        self.bt1.grid(row=len(self.labels), columnspan=2, pady=20)  # Place the button below the entry fields

        self.geometry("800x600")  # Set the window size

    def add_trainer_info(self):
        name = self.entry_fields[0].get()
        height = self.entry_fields[1].get()
        weight = self.entry_fields[2].get()
        experience = self.entry_fields[3].get()
        clients = self.entry_fields[4].get()
        hours = self.entry_fields[5].get()
        trainer_id = self.entry_fields[6].get()

        if not all([name, height, weight, experience, clients, hours]):
            messagebox.showwarning("Warning", "Please fill in all required fields.")
            return
        # Input validation
        if not re.match(r'^[a-zA-Z\s]+$', name):
            messagebox.showerror("Error", "Please enter alphabets and spaces only for the name.")
            return
        try:
            height = int(height)
            weight = int(weight)
            experience = int(experience)
            clients = int(clients)
            hours = int(hours)
        except ValueError:
            messagebox.showerror("Error", "Please enter integer values for height, weight, experience, clients, and hours worked.")
            return

        try:
            conn = psycopg2.connect(dbname="gym_db", user="postgres", password="Anish@534", host="localhost", port="5432")
            cursor = conn.cursor()
            insert_query = "INSERT INTO trainer_info (name, height, weight, experience, clients, hours_worked, trainer_id) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            cursor.execute(insert_query, (name, height, weight, experience, clients, hours, trainer_id))
            conn.commit()
            messagebox.showinfo("Success", "Trainer information added successfully!")
        except psycopg2.IntegrityError as e:
            if "unique constraint" in str(e):
                messagebox.showwarning("Warning", "Trainer ID ALREADY EXISTS. ENTER A NEW ONE.")
            else:
                messagebox.showerror("Error", f"Error adding Trainer information: {e}")

        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

def main():
    app = AddTrainer()
    app.mainloop()

if __name__ == "__main__":
    main()
