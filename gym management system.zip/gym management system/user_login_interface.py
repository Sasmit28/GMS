import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk  # Import PIL modules for image handling
import subprocess  # For running external scripts
from login_interface import Login

class GymManagementSystem(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('USER LOGIN')
        self.geometry('1920x1080')  # Set the window size to 800x600

        # Load the background image
        background_image = Image.open('adminlogin.png')
        self.background_photo = ImageTk.PhotoImage(background_image)

        # Create a label to hold the background image
        self.bg_label = tk.Label(self, image=self.background_photo)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)

        # Create a frame on top of the background label with padding and curved edges
        self.frame = tk.Frame(self.bg_label, bg="#292826", bd=10, relief=tk.RAISED, padx=20, pady=20)
        self.frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        # Create buttons for different functionalities
        button_config = {'width': 25, 'height': 4, 'bg': '#f4f4f4', 'fg': 'black', 'bd': 10, 'relief': tk.RAISED, }

        attendance_button = tk.Button(self.frame, text='Attendance', command=self.open_attendance_interface,font=("Arial", 14))
        attendance_button.config(**button_config)
        attendance_button.pack(pady=10)

        view_attendance_button = tk.Button(self.frame, text='View Attendance', command=self.open_attendance_viewer,font=("Arial", 14))
        view_attendance_button.config(**button_config)
        view_attendance_button.pack(pady=10)

        renew_membership_button = tk.Button(self.frame, text='Renew Membership', command=self.open_renew_membership,font=("Arial", 14))
        renew_membership_button.config(**button_config)
        renew_membership_button.pack(pady=10)

        #send_mail_button = tk.Button(self.frame, text='Send Mail', command=self.open_send_mail,font=("Arial", 14))
        #send_mail_button.config(**button_config)
        #send_mail_button.pack(pady=10)

        logout_button = tk.Button(self.frame, text='Logout', command=self.logout,font=("Arial", 14))
        logout_button.config(**button_config)
        logout_button.pack(pady=10)

    # Function to open the attendance interface
    def open_attendance_interface(self):
        subprocess.Popen(['python', 'attendence_interface.py'])

    # Function to open the attendance viewer interface
    def open_attendance_viewer(self):
        subprocess.Popen(['python', 'attendence_viewer.py'])

    # Function to open the renew membership interface
    def open_renew_membership(self):
        subprocess.Popen(['python', 'renew_membership.py'])

    # Function to open the send mail interface
    def open_send_mail(self):
        # Add your code here to implement the send mail functionality
        messagebox.showinfo('Send Mail', 'This feature is not implemented yet.')

    # Function to logout and go back to the login interface
    def logout(self):
        self.destroy()  # Close the main window
        login_window = Login()  # Create a new instance of the Login window
        login_window.mainloop()

if __name__ == "__main__":
    app = GymManagementSystem()
    app.mainloop()
