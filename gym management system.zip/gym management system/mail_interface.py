import smtplib
import psycopg2
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import date

# Define the subject variable
subject = 'Membership Renewal Notification'

# Function to send email
def send_email(sender_email, sender_password, receiver_email, subject, body):
    try:
        smtp_server = 'smtp.gmail.com'
        port = 587

        # Create message container
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = subject

        # Email body
        msg.attach(MIMEText(body, 'plain'))

        # Send email
        server = smtplib.SMTP(smtp_server, port)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, receiver_email, msg.as_string())
        server.quit()
        print(f"Email sent to {receiver_email} successfully.")
    except Exception as e:
        print("Error sending email:", e)

# Function to check membership expiry and send emails
def check_membership_expiry_and_send_emails():
    try:
        connection = psycopg2.connect(
            user="postgres",
            password="Anish@534",
            host="localhost",
            port="5432",
            database="gym_db"
        )
        cursor = connection.cursor()
# Get current date
        today = date.today()
# Fetch members whose memberships have expired
        cursor.execute("SELECT gymid , email FROM members WHERE expiry_date < %s", (today,))
        expired_members = cursor.fetchall()

        sender_email = 'f1tvpro6@gmail.com'
        sender_password = 'Anish@534'  # or the generated app password
        body = "Dear Member,\n\nYour membership has expired. Please renew your membership to continue accessing our services.\n\nRegards,\nGym Management System"
# Send email to each expired member
        for member_id, email in expired_members:
            send_email(sender_email, sender_password, email, subject, body)
         cursor.close()
        connection.close()
        print("Membership renewal emails sent successfully.")
    except psycopg2.Error as e:
        print("Error while connecting to PostgreSQL:", e)
    except Exception as e:
        print("Error:", e)

# Example function to be called when the button is clicked in the GUI
def on_membership_renew_mail_button_click():
    check_membership_expiry_and_send_emails()

# Call this function when the button is clicked in your Tkinter GUI
on_membership_renew_mail_button_click()
